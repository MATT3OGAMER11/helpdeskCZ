create definer = root@localhost view chat_ata as
select `c`.`nome`      AS `nomechat`,
       `c`.`id_ruolo`  AS `id_ruolo`,
       `m`.`id`        AS `id_messaggio`,
       `m`.`messaggio` AS `messaggio`,
       `m`.`data`      AS `data`,
       `u`.`nome`      AS `nome`,
       `u`.`cognome`   AS `cognome`,
       `u`.`id`        AS `id_utente`
from ((`helpdesk`.`chat` `c` join `helpdesk`.`messaggio` `m` on (`m`.`id_chat` = `c`.`id`)) join `helpdesk`.`utente` `u`
      on (`u`.`id` = `m`.`id_utente` and `c`.`id` = 2));

